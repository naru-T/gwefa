

library(foreach)
library(doMC)

library(gwfa)

debug(gwfa)

load <- array(NA,c(ep.n,var.n,k))
resid_sqsum <- rep(NA, nrow(elocat))
s <- matrix(NA,ep.n,k)
u <- matrix(NA,ep.n,var.n)
ld <- matrix(NA,ep.n,k)
ss <- matrix(NA,ep.n,k)
cor.mt <- matrix(NA,ep.n,sum(seq(1,(k-1),1)))
rmsea <- rep(NA, nrow(elocat))
score.all <-  matrix(NA,ep.n,k)

registerDoMC(2)
out <- foreach(i= 1:ep.n) %dopar% {
#for (i in 1:ep.n) {
  
  score.all <-  matrix(NA,ep.n,k)
  
  if (DM.given)
    dist.vi <- dMat[, i]
  else {
    if (ep.given)
      dist.vi <- gw.dist(dp.locat, elocat, focus = i,
                         p, theta, longlat)
    else dist.vi <- gw.dist(dp.locat, focus = i, p = p,
                            theta = theta, longlat = longlat)
  }
  wt <- gw.weight(dist.vi, bw, kernel, adaptive)
  use <- wt > 0
  wt <- wt[use]
  if (length(wt) <= 5) {
    expr <- paste("Too small bandwidth at location: ",
                  i)
    warning(paste(expr, "and the results can't be given there.",
                  sep = ", "))
    next
  }
  
  temp <- wfa(x=data[use, ], wt, factors=k, scores=scores, n.obs, fm=fm, rotate=rotate, oblique.scores=oblique.scores, timeout=timeout)


  if(is.null(temp)){
    load <- NA
    score.all <- NA
    s <- NA
    u <- NA
    ld<- NA
    ss <- NA
    cortemp <- NA
    cor.mt <- NA
    resid_sqsum <- NA
    rmsea <- NA
    
  } else {
    
    colnm <- colnames(temp$scores)
    load <- matrix(temp$loadings[, order(colnm)], ncol=k, nrow=var.n)
    #score
    
    score.all[use, ] <- temp$scores[, order(colnm)]
    s <- score.all[i,]
    u <- temp$uniquenesses
    ld<- temp$Vaccounted[1,order(colnm)]
    ss <- temp$Vaccounted[2,order(colnm)]
    cortemp <- cor(temp$scores[,order(colnm)])
    cor.mt <- cortemp[upper.tri(cortemp)] #correlation between factor scores
    resid_sqsum <- sum(temp$residual[upper.tri(temp$residual)]^2, na.rm=TRUE)
    rmsea <- temp$RMSEA[1]
  }
  
  list(
    loadings=load,
    score=s,
    uniquenesses=u,
    loading_score=ld,
    residuals_sqsum = resid_sqsum,
    ss=ss,
    cor.mt=cor.mt,
    rmsea=rmsea)
}

res <- list(
 # loadings = lapply(out,"[[","loadings") %>% unlist()
  loadings = array(as.numeric(unlist(lapply(out,"[[","loadings"))), dim=c(c(ep.n,var.n,k))),
  score = t(sapply(out,"[[", 'score')),
  uniquenesses = t(sapply(out,"[[","uniquenesses")),
  loading_score = t(sapply(out,"[[","loading_score")),
  residuals_sqsum = t(sapply(out,"[[","residuals_sqsum")) %>% as.numeric(),
  ss = t(sapply(out,"[[","ss")),
  cor.mt = t(sapply(out,"[[","cor.mt")),
  rmsea = t(sapply(out,"[[","rmsea")) %>% as.numeric()
)


#dimnames(load)[[3]] <- colnames(out[[1]]$loadings)[order(colnames(out[[1]]$loadings))]


##SAME!
gwfa.shp <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp <- cbind(gwfa.shp, gwfa.ans$uniquenesses) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp[,1])

gwfa.shp_foreach <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp_foreach <- cbind(gwfa.shp_foreach, gwfa.ans_foreach$uniquenesses) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp_foreach[,1])

#SAME
gwfa.shp <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp <- cbind(gwfa.shp, gwfa.ans$score) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp[,2])

gwfa.shp_foreach <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp_foreach <- cbind(gwfa.shp_foreach, gwfa.ans_foreach$score) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp_foreach[,2])

#SAME!
gwfa.shp <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp <- cbind(gwfa.shp, gwfa.ans$cor.mt) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp[,2])

gwfa.shp_foreach <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp_foreach <- cbind(gwfa.shp_foreach, gwfa.ans_foreach$cor.mt) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp_foreach[,2])

#same
gwfa.shp <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp <- cbind(gwfa.shp, gwfa.ans$rmsea) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp[,1])

gwfa.shp_foreach <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp_foreach <- cbind(gwfa.shp_foreach, gwfa.ans_foreach$rmsea) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp_foreach[,1])

#LOAD
gwfa.shp <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp <- cbind(gwfa.shp, gwfa.ans$loadings[,,1]) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp[,3])

gwfa.shp_foreach <-  shp_scale %>% dplyr::select(ZAGE0014) 
gwfa.shp_foreach <- cbind(gwfa.shp_foreach, gwfa.ans_foreach$loadings[,,1]) %>%  dplyr::select(-ZAGE0014) 
spplot(gwfa.shp_foreach[,3])
