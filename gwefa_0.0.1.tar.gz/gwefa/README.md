# gwefa
geographically weighted exploratory factor analysis

citation: Tsutsumida N., Murakami D., Yoshida T., Pravitasari A.E., Nakaya T. Spatially explicit exploratory factor analysis on urban statistical data – Geographically weighted approach –, International Conference on Spatial Analysis and Modeling, Tokyo, 8-9, September, 2018.
